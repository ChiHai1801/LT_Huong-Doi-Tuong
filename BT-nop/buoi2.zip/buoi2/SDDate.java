package buoi2;

public class SDDate {

	public static void main(String[] args) {
		Date d = new Date();
		d.NhapNgay();
		d.hienThi();
		d.ngayHomSau().hienThi();
	}

}
