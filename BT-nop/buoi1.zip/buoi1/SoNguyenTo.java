package buoi1;		// bai:6

import java.util.Scanner;

public class SoNguyenTo {

	public static boolean laSoNguyenTo(int n) {
		if(n<=1)
			return false;
		else
			for (int i=2; i<n; i++)
				if(n%i == 0)
					return false;
		return true;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập n: ");
		int n = sc.nextInt();
		if(laSoNguyenTo(n))
		{
			System.out.print( n + " Là số nguyên tố " + "\n Nhị phân của " + n + " là: ");
			System.out.print(Integer.toBinaryString(n));
		}
		else
			System.out.print(n + " Không là số nguyên tố");
	}
}

